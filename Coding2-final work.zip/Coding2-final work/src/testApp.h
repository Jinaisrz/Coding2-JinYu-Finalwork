#ifndef _TEST_APP
#define _TEST_APP
#include "ofMain.h"
#include "ofxGui.h"
#include <vector>
#include "Snowflake.hpp"
#include "NewSnowflake.hpp"

class testApp : public ofBaseApp{
	
public:
    ~testApp();
	
    void setup();
    void update();
    void draw();
    void keyPressed(int key);

   
    
    ofSerial serial;

   
    
    std::vector<Snowflake *> Snowflakes;
    std::vector<NewSnowflake *> new_Snowflakes;
    
    ofxPanel gui;
    bool bHide;
    ofxFloatSlider radius;
    ofxFloatSlider radius1;
    ofxFloatSlider radius2;
     ofxColorSlider color;
     ofxVec2Slider center;
     ofxIntSlider circleResolution;
     ofxToggle filled;
     ofxButton twoCircles;
     ofxButton ringButton;
     ofxLabel screenSize;

};

#endif	
