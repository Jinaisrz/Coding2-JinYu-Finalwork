#include "testApp.h"

testApp::~testApp()
{
	for (int i = 0; i < Snowflakes.size(); i++)
	{
		delete Snowflakes[i];
	}
    
    for (int i = 0; i < new_Snowflakes.size(); i++)
    {
        delete new_Snowflakes[i];
    }
}
// I pass the destructor), located in the class named "testApp". It is responsible for deleting all created Snowflakes objects, and new_Snowflakes objects, when the object is destroyed (freed from memory).

// Where Snowflakes and new_Snowflakes are both containers, which may be vectors or arrays. for loop frees the dynamically allocated memory occupied by each element by iterating over all the elements in the container, using the delete operator.

// The purpose of this destructor is to clean up the memory occupied by the objects of the class, ensuring that no memory leaks occur during program execution, thus improving the robustness and reliability of the program.

//--------------------------------------------------------------
void testApp::setup(){
    ofSetBackgroundColorHex(0x313577);
    ofSetBackgroundAuto(false);
    
    ofSetWindowTitle("Jin Yu");
    ofSetFrameRate(60);


        gui.setup(); // most of the time you don't need a name
        gui.add(filled.setup("Light", true));
        gui.add(radius.setup("Size1", 4, 1, 10));
        gui.add(radius1.setup("Size2", 4, 1, 10));

        bHide = false;

	
	// set up the snowflakes and new snowflakes
    for (int i = 0; i < 10; i++){
        Snowflakes.push_back(new Snowflake());
        Snowflakes[i]->setColor(ofColor(255));
    }
    
    for (int i = 0; i < 5; i++){
        new_Snowflakes.push_back(new NewSnowflake());
        new_Snowflakes[i]->setColor(ofColor(5,10,10));
    }
    
    serial.setup(0, 115200);
    
    // The destructor function is used to free dynamically allocated memory at the end of the program. The function loops through the vector container in which the snowflake is stored, calling the delete operator on each of its elements to free the corresponding memory space.
    
}


//--------------------------------------------------------------
void testApp::update(){
    
    
    while (serial.available() > 0) {
        cout<<serial.readByte()<<endl;
        Snowflakes.push_back(new Snowflake());
        new_Snowflakes.push_back(new NewSnowflake());
        for (int i = 0; i < Snowflakes.size(); i++){
            Snowflakes[i]->setColor(ofColor(ofRandom(20),ofRandom(25),ofRandom(20)));
        }
//        for (int i = 0; i < new_Snowflakes.size(); i++){
//            new_Snowflakes[i]->setColor(ofColor(ofRandom(0),ofRandom(25),ofRandom(25)));
//        }
    }
    
    
   
	
	for (int i = 0; i < Snowflakes.size(); i++)
	{
        Snowflakes[i]->update(Snowflakes);
	}
    
    for (int i = 0; i < new_Snowflakes.size(); i++)
    {
        new_Snowflakes[i]->update(new_Snowflakes);
    }
    
    ofSetColor(0x313577);
    ofDrawRectangle(0, 0, ofGetWidth(), ofGetHeight());
 
}

// The setup function is used to initialise the application. In this function the background colour and title of the application window are set, as well as the frame rate. A GUI object is also created and some parameters are added, where the default value of the parameter filled is true and the default values of radius and radius1 are 4 respectively, ranging from 1 to 10. Then, 10 Snowflake objects and 5 NewSnowflake objects are created and their colours are set to ofColor (255) and ofColor(5, 10, 10). Finally, the setup function of the serial port object was called and used to communicate with the hardware device.

//--------------------------------------------------------------
void testApp::draw(){
    for (int i = 0; i < Snowflakes.size(); i++){
        Snowflakes[i]->draw(radius);
    }
    
    for (int i = 0; i < new_Snowflakes.size(); i++){
        new_Snowflakes[i]->newdraw(radius1);
    }
    ofSetBackgroundColorHex(0x313577);
    
    if(!bHide){
            gui.draw();
        }
}
// First, the snowflakes are drawn by iterating through all the elements in the Snowflakes container and calling the draw function on each element.

// Then, the new snowflakes are drawn by iterating through all the elements in the new_Snowflakes container, calling the newdraw function for each element.

// Next, the background colour is set to a hexadecimal value (0x313577) by calling the ofSetBackgroundColorHex function.

// Finally, the value of the bHide variable is used to determine whether the graphical user interface (GUI) should be displayed. If the value of bHide is false, the draw function of the GUI object is called and the GUI is drawn.

//--------------------------------------------------------------
void testApp::keyPressed(int key){
    if(key == 'a'){
        Snowflakes.push_back(new Snowflake());
        new_Snowflakes.push_back(new NewSnowflake());
        
        for (int i = 0; i < Snowflakes.size(); i++){
            Snowflakes[i]->setColor(ofColor(ofRandom(0),ofRandom(13),ofRandom(0)));
        }
        for (int i = 0; i < Snowflakes.size(); i++){
            Snowflakes[i]->setColor(ofColor(255,255,255));
        }


    }
}
// The code is executed by determining whether the key pressed by the user is the 'a' key or not. If it is the 'a' key, then the following code is executed. Next, a new Snowflake object and a new NewSnowflake object are added to the Snowflakes container and new_Snowflakes container respectively by calling the push_back function. Then, set the colours of all the elements in the Snowflakes container by iterating through them and calling the setColor function for each element. Here, the ofColor function is used to generate a random colour and is passed as an argument to the setColor function. Then, all the elements in the Snowflakes container are iterated through again, calling each element's setColor function to set its colour to white.
