#include "NewSnowflake.hpp"

void NewSnowflake::newdraw(int a)
{
    ofSetColor(color);
    image.draw(position.x+100,position.y,(size+a*10),(size+a*10));
}
ofVec3f NewSnowflake::separation(std::vector<NewSnowflake *> &otherSnowflakes)
{
    // finds the first collision and avoids that
    // should probably find the nearest one
    // can you figure out how to do that?
    for (int i = 0; i < otherSnowflakes.size(); i++)
    {
        if(position.distance(otherSnowflakes[i]->getPosition()) < separationThreshold)
        {
            ofVec3f v = position - otherSnowflakes[i]->getPosition();
            v.normalize();
            return blow_force*v;
        }
    }
    return ofVec3f(0,0,0);
}
void NewSnowflake::update(std::vector<NewSnowflake *> &otherSnowflakes)
{
    
    velocity += separationWeight*separation(otherSnowflakes);
    velocity += cohesionWeight*cohesion();
    velocity += alignmentWeight*alignment();
 
    walls();
    constrainSpeed();
    position += velocity;
}
