#ifndef Snowflake_hpp
#define Snowflake_hpp

#include <stdio.h>
#include "ofMain.h"

class Snowflake
{
    // all the methods and variables after the
    // public keyword can only be used by anyone
    public:
        Snowflake();
        Snowflake(ofVec3f &pos, ofVec3f &vel);
    
        ~Snowflake();
    
        ofVec3f getPosition();
        ofVec3f getVelocity();
    
    float separationWeight;
    float cohesionWeight;
    float alignmentWeight;
    float separationThreshold;
    float neighbourhoodSize;

    ofVec3f separation(std::vector<Snowflake *> &otherSnowflakes);
    ofVec3f cohesion();
    ofVec3f alignment();
    
    ofVec3f position;
    ofVec3f velocity;
    ofImage image;
    float size;
    float blow_force;
    ofVec3f max_velocity;
    ofColor color = ofColor(5);
    
    
        float getSeparationWeight();
        float getCohesionWeight();
        float getAlignmentWeight();
    
        float getSeparationThreshold();
        float getNeighbourhoodSize();
    
        void setSeparationWeight(float f);
        void setCohesionWeight(float f);
        void setAlignmentWeight(float f);
    
        void setSeparationThreshold(float f);
        void setNeighbourhoodSize(float f);
    
        void update(std::vector<Snowflake *> &otherSnowflakes);
    
        void walls();
        void constrainSpeed();
        void set_blow(float force);
        void set_maxForce(float f);
        void draw(int a);
        void setColor(ofColor c);
    
    void changeColor();
    
};

#endif /* Snowflake_hpp */
