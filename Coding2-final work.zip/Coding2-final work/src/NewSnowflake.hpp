#ifndef NewSnowflake_hpp
#define NewSnowflake_hpp

#include <stdio.h>
#include "ofMain.h"
#include "Snowflake.hpp"

class NewSnowflake : public Snowflake
{
public:
    void newdraw(int a);
    void update(std::vector<NewSnowflake *> &otherSnowflakes);
    ofVec3f separation(std::vector<NewSnowflake *> &otherSnowflakes);
};

#endif /* NewFlower_hpp */
