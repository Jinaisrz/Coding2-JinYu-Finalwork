#include "Snowflake.hpp"
#include "ofMain.h"

Snowflake::Snowflake()
{
    separationWeight = 1.0f;
    cohesionWeight = 0.2f;
    alignmentWeight = 0.1f;
 
    separationThreshold = 15;
    neighbourhoodSize = 100;
 
    position = ofVec3f(ofRandom(0, 200), ofRandom(0, 200));
    velocity = ofVec3f(ofRandom(-1, 1), ofRandom(-1, 1));
    max_velocity = ofVec3f(ofRandom(0.8,1.2), ofRandom(0.8,1.2));
    
    blow_force = 0.1;
    
    image.load("Snowflake.png");
    size = ofRandom(30,60);
}

Snowflake::Snowflake(ofVec3f &pos, ofVec3f &vel)
{
    separationWeight = 1.0f;
    cohesionWeight = 0.2f;
    alignmentWeight = 0.1f;
 
    separationThreshold = 15;
    neighbourhoodSize = 100;
  
    position = pos;
    velocity = vel;
    max_velocity = ofVec3f(2, 2);
    
}

Snowflake::~Snowflake()
{
 
}

float Snowflake::getSeparationWeight()
{
    return separationWeight;
}
float Snowflake::getCohesionWeight()
{
    return cohesionWeight;
}

float Snowflake::getAlignmentWeight()
{
    return alignmentWeight;
}


float Snowflake::getSeparationThreshold()
{
    return separationThreshold;
}

float Snowflake::getNeighbourhoodSize()
{
    return neighbourhoodSize;
}


void Snowflake::setSeparationWeight(float f)
{
    separationWeight = f;
}
void Snowflake::setCohesionWeight(float f)
{
    cohesionWeight = f;
}

void Snowflake::setAlignmentWeight(float f)
{
    alignmentWeight = f;
}


void Snowflake::setSeparationThreshold(float f)
{
    separationThreshold = f;
}

void Snowflake::setNeighbourhoodSize(float f)
{
    neighbourhoodSize = f;
}


ofVec3f Snowflake::getPosition()
{
    return position;
}

ofVec3f Snowflake::getVelocity()
{
    return velocity;
}

ofVec3f Snowflake::separation(std::vector<Snowflake *> &otherSnowflakes)
{
    // finds the first collision and avoids that
    // should probably find the nearest one
    // can you figure out how to do that?
    for (int i = 0; i < otherSnowflakes.size(); i++)
    {
        if(position.distance(otherSnowflakes[i]->getPosition()) < separationThreshold)
        {
            ofVec3f v = position - otherSnowflakes[i]->getPosition();
            v.normalize();
            return blow_force*v;
        }
    }
    return ofVec3f(0,0,0);
}

ofVec3f Snowflake::cohesion()
{
    ofVec3f v =  ofVec3f(ofGetMouseX(),ofGetMouseY(),0) - position;
    v.normalize();
    return 0.1*v;
}

ofVec3f Snowflake::alignment()
{
    ofVec3f v =  ofVec3f(ofGetMouseX(),ofGetMouseY(),0) - position;
    v.normalize();
    return 0.1*v;
}

void Snowflake::update(std::vector<Snowflake *> &otherSnowflakes)
{
    
    velocity += separationWeight*separation(otherSnowflakes);
    velocity += cohesionWeight*cohesion();
    velocity += alignmentWeight*alignment();
 
    walls();
    constrainSpeed();
    position += velocity;
}

void Snowflake::constrainSpeed()
{
    if(abs(velocity.x) > abs(max_velocity.x)){
        if(velocity.x < 0) velocity.x = - max_velocity.x - ofRandom(-0.2,0.2);
        else velocity.x = max_velocity.x - ofRandom(-0.2,0.2);
    }
    if(abs(velocity.y) > abs(max_velocity.y)){
        if(velocity.y < 0) velocity.y = -max_velocity.y - ofRandom(-0.2,0.2);
        else velocity.y = max_velocity.y - ofRandom(-0.2,0.2);
    }
}

void Snowflake::walls()
{
    if (position.x > ofGetWidth()){
        position.x = 0;
    } else if (position.x < 0){
        position.x = ofGetWidth();
    }
    if (position.y > ofGetHeight()){
        position.y = 0;
    } else if (position.y < 0){
        position.y = ofGetHeight();
    }
}


void Snowflake::setColor(ofColor c)
{
    color = c;
}

void Snowflake::draw(int a)
{
    ofSetColor(color);
    image.draw(position.x,position.y,(size+a*10),(size+a*10));
}


void Snowflake::set_blow(float force)
{
    blow_force = force;
}

void Snowflake::set_maxForce(float f)
{
    max_velocity.x = f + ofRandom(-0.2,0.2);
    max_velocity.y = f + ofRandom(-0.2,0.2);
}
